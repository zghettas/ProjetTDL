/**
 * 
 */
package fr.n7.stl.block.ast;

/**
 * @author Marc Pantel
 *
 */
public class ForbiddenDeclarationException extends Exception {

}
